# Fleet.Vehicles 1.0.0: Test data generation

## General hint
In total there are 50.000 test data sets. This results in big files.
Especially for JSON file format the amount of test data sets was reduced to 5000.

## Adaption from CX release 3.0 test data to CX release 3.2 test data

| column      | Modification |
| ----------- | ----------- |
|all columns| now in aphabetical order, besides foreign keys. |
|all catenaXId columns| Now using generated UUIDs that can be validated with regex|

## Content test data files CX release 3.2
Naming convention for test data zip container: <br>
CX_\<Catena-X release number\>\_\<aspect model\>\_\<aspect model version\>\_testdata\_\<test data version\>.zip
<br><br>
Included files:

- CX_release32_qax_fleet_vehicles-v100_testdata_v100: Test data in one big file<br>
Formats: csv, json, parquet, xlsx

- listOfVehicles.vehicle: Normalized test data: Only properties of root entity.<br> 
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.oem: Normalized test data: Only properties of entity oem + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.body: Normalized test data: Only properties of entity body + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.equipments: Normalized test data: Only properties of entity equipments + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.production: Normalized test data: Only properties of entity production + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.sale: Normalized test data: Only properties of entity sale + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.engines: Normalized test data: Only properties of entity engines + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx

- listOfVehicles.vehicle.fuel: Normalized test data: Only properties of entity fuel + foreignKey anonymizedVin <br>
Formats: csv, parquet, xlsx