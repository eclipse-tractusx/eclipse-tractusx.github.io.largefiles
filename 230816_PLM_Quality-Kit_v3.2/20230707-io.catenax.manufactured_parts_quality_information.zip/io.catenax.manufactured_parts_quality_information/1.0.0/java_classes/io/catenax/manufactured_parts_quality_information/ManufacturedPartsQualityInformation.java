
package io.catenax.manufactured_parts_quality_information;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;

/**
 * Generated class for Quality information for parts. This aspect model is used
 * to exchange manufacturing-oriented information of several parts, e.g. for
 * quality tasks
 */
public class ManufacturedPartsQualityInformation implements CollectionAspect<List<ManufacturedPart>, ManufacturedPart> {

	@NotNull
	private List<ManufacturedPart> listOfManufacturedParts;

	@JsonCreator
	public ManufacturedPartsQualityInformation(
			@JsonProperty(value = "listOfManufacturedParts") List<ManufacturedPart> listOfManufacturedParts) {
		super(

		);
		this.listOfManufacturedParts = listOfManufacturedParts;
	}

	/**
	 * Returns Manufactured parts
	 *
	 * @return {@link #listOfManufacturedParts}
	 */
	public List<ManufacturedPart> getListOfManufacturedParts() {
		return this.listOfManufacturedParts;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final ManufacturedPartsQualityInformation that = (ManufacturedPartsQualityInformation) o;
		return Objects.equals(listOfManufacturedParts, that.listOfManufacturedParts);
	}

	@Override
	public int hashCode() {
		return Objects.hash(listOfManufacturedParts);
	}
}
