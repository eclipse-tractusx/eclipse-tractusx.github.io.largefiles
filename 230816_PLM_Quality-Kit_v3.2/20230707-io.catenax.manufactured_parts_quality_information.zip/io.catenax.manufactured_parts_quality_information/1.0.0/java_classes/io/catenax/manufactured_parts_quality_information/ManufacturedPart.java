
package io.catenax.manufactured_parts_quality_information;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * Generated class for Manufactured part. Manufacturing information for one
 * part. Important properties are standardized. Besides that there is a
 * key:value list to exchange further non-standardized properties for this part
 */

public class ManufacturedPart {
	@Pattern(regexp = "(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)|(^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)")

	private Optional<String> catenaXId;
	private Optional<String> qualityTaskId;

	@NotNull
	private String manufacturerId;
	private Optional<String> manufacturerSerialPartNumber;

	@NotNull
	private String nameAtManufacturer;

	@NotNull
	private Manufacturing manufacturingInformation;

	@JsonCreator
	public ManufacturedPart(@JsonProperty(value = "catenaXId") Optional<String> catenaXId,
			@JsonProperty(value = "qualityTaskId") Optional<String> qualityTaskId,
			@JsonProperty(value = "manufacturerId") String manufacturerId,
			@JsonProperty(value = "manufacturerSerialPartNumber") Optional<String> manufacturerSerialPartNumber,
			@JsonProperty(value = "nameAtManufacturer") String nameAtManufacturer,
			@JsonProperty(value = "manufacturingInformation") Manufacturing manufacturingInformation) {
		super(

		);
		this.catenaXId = catenaXId;
		this.qualityTaskId = qualityTaskId;
		this.manufacturerId = manufacturerId;
		this.manufacturerSerialPartNumber = manufacturerSerialPartNumber;
		this.nameAtManufacturer = nameAtManufacturer;
		this.manufacturingInformation = manufacturingInformation;
	}

	/**
	 * Returns Catena-X ID
	 *
	 * @return {@link #catenaXId}
	 */
	public Optional<String> getCatenaXId() {
		return this.catenaXId;
	}

	/**
	 * Returns Quality Task ID
	 *
	 * @return {@link #qualityTaskId}
	 */
	public Optional<String> getQualityTaskId() {
		return this.qualityTaskId;
	}

	/**
	 * Returns Manufacturer ID
	 *
	 * @return {@link #manufacturerId}
	 */
	public String getManufacturerId() {
		return this.manufacturerId;
	}

	/**
	 * Returns Manufacturer serial part number
	 *
	 * @return {@link #manufacturerSerialPartNumber}
	 */
	public Optional<String> getManufacturerSerialPartNumber() {
		return this.manufacturerSerialPartNumber;
	}

	/**
	 * Returns Manufacturer part name
	 *
	 * @return {@link #nameAtManufacturer}
	 */
	public String getNameAtManufacturer() {
		return this.nameAtManufacturer;
	}

	/**
	 * Returns Manufacturing information
	 *
	 * @return {@link #manufacturingInformation}
	 */
	public Manufacturing getManufacturingInformation() {
		return this.manufacturingInformation;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final ManufacturedPart that = (ManufacturedPart) o;
		return Objects.equals(catenaXId, that.catenaXId) && Objects.equals(qualityTaskId, that.qualityTaskId)
				&& Objects.equals(manufacturerId, that.manufacturerId)
				&& Objects.equals(manufacturerSerialPartNumber, that.manufacturerSerialPartNumber)
				&& Objects.equals(nameAtManufacturer, that.nameAtManufacturer)
				&& Objects.equals(manufacturingInformation, that.manufacturingInformation);
	}

	@Override
	public int hashCode() {
		return Objects.hash(catenaXId, qualityTaskId, manufacturerId, manufacturerSerialPartNumber, nameAtManufacturer,
				manufacturingInformation);
	}
}
