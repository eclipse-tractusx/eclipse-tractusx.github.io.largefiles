
package io.catenax.manufactured_parts_quality_information;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Manufacturing. Collection of defined
 * manufacturing-related properties for this part
 */

public class Manufacturing {

	@NotNull
	private XMLGregorianCalendar date;

	@NotNull
	@Pattern(regexp = "^[A-Z][A-Z][A-Z]$")

	private String country;

	@NotNull
	private String plantId;

	@NotNull
	private String plantDescription;

	@NotNull
	private String batchId;
	private Optional<String> productionLine;
	private Optional<Boolean> hasBeenReworked;
	private Optional<BigInteger> numberOfConductedEOLTests;
	private Optional<List<AdditionalInformation>> addtionalInformation;

	@JsonCreator
	public Manufacturing(@JsonProperty(value = "date") XMLGregorianCalendar date,
			@JsonProperty(value = "country") String country, @JsonProperty(value = "plantId") String plantId,
			@JsonProperty(value = "plantDescription") String plantDescription,
			@JsonProperty(value = "batchId") String batchId,
			@JsonProperty(value = "productionLine") Optional<String> productionLine,
			@JsonProperty(value = "hasBeenReworked") Optional<Boolean> hasBeenReworked,
			@JsonProperty(value = "numberOfConductedEOLTests") Optional<BigInteger> numberOfConductedEOLTests,
			@JsonProperty(value = "addtionalInformation") Optional<List<AdditionalInformation>> addtionalInformation) {
		super(

		);
		this.date = date;
		this.country = country;
		this.plantId = plantId;
		this.plantDescription = plantDescription;
		this.batchId = batchId;
		this.productionLine = productionLine;
		this.hasBeenReworked = hasBeenReworked;
		this.numberOfConductedEOLTests = numberOfConductedEOLTests;
		this.addtionalInformation = addtionalInformation;
	}

	/**
	 * Returns Production Date
	 *
	 * @return {@link #date}
	 */
	public XMLGregorianCalendar getDate() {
		return this.date;
	}

	/**
	 * Returns Country code
	 *
	 * @return {@link #country}
	 */
	public String getCountry() {
		return this.country;
	}

	/**
	 * Returns Plant id
	 *
	 * @return {@link #plantId}
	 */
	public String getPlantId() {
		return this.plantId;
	}

	/**
	 * Returns Plant description
	 *
	 * @return {@link #plantDescription}
	 */
	public String getPlantDescription() {
		return this.plantDescription;
	}

	/**
	 * Returns Batch number
	 *
	 * @return {@link #batchId}
	 */
	public String getBatchId() {
		return this.batchId;
	}

	/**
	 * Returns Production line
	 *
	 * @return {@link #productionLine}
	 */
	public Optional<String> getProductionLine() {
		return this.productionLine;
	}

	/**
	 * Returns Reworked
	 *
	 * @return {@link #hasBeenReworked}
	 */
	public Optional<Boolean> isHasBeenReworked() {
		return this.hasBeenReworked;
	}

	/**
	 * Returns Conducted EOL test
	 *
	 * @return {@link #numberOfConductedEOLTests}
	 */
	public Optional<BigInteger> getNumberOfConductedEOLTests() {
		return this.numberOfConductedEOLTests;
	}

	/**
	 * Returns Additional information
	 *
	 * @return {@link #addtionalInformation}
	 */
	public Optional<List<AdditionalInformation>> getAddtionalInformation() {
		return this.addtionalInformation;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Manufacturing that = (Manufacturing) o;
		return Objects.equals(date, that.date) && Objects.equals(country, that.country)
				&& Objects.equals(plantId, that.plantId) && Objects.equals(plantDescription, that.plantDescription)
				&& Objects.equals(batchId, that.batchId) && Objects.equals(productionLine, that.productionLine)
				&& Objects.equals(hasBeenReworked, that.hasBeenReworked)
				&& Objects.equals(numberOfConductedEOLTests, that.numberOfConductedEOLTests)
				&& Objects.equals(addtionalInformation, that.addtionalInformation);
	}

	@Override
	public int hashCode() {
		return Objects.hash(date, country, plantId, plantDescription, batchId, productionLine, hasBeenReworked,
				numberOfConductedEOLTests, addtionalInformation);
	}
}
