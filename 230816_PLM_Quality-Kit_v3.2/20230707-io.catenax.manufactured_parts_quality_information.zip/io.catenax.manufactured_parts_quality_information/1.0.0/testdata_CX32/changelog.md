# manufactured_parts_quality_information 1.0.0: Test data generation

## General hint

## Adaption from CX release 3.0 test data to CX release 3.2 test data
All column names changed: \<listOfManufacturedParts\> prefix removed.<br>

| column      | Modification |
| ----------- | ----------- |
|all columns| now in aphabetical order
|all catenaXId columns| Now using generated UUIDs that can be validated with regex|

## Content test data files CX release 3.2
Naming convention for test data zip container: <br>

Included files:

- CX_release32_qax_manufactured_parts_quality_information-v100_testdata_v100: Test data in one big file<br>
Formats: csv, json, parquet, xlsx