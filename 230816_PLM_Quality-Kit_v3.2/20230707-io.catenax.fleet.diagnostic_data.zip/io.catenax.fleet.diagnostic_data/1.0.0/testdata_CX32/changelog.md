# fleet.diagnostic_data 1.0.0: Test data generation

## General hint
In total there are 50.000 test data sets. This results in big files.
Especially for JSON file format the amount of test data sets was reduced to 5000.

## Adaption from CX release 3.0 test data to CX release 3.2 test data
All column names changed: \<diagnosticSessions\> prefix removed.<br>
Due to the fact that some property names are the same: Reduction of column names to only property name does not work.

| column      | Modification |
| ----------- | ----------- |
|all columns| now in aphabetical order|
|all catenaXId columns| Now using generated UUIDs that can be validated with regex|

## Content test data files CX release 3.2
Naming convention for test data zip container: <br>
CX_\<Catena-X release number\>\_\<aspect model\>\_\<aspect model version\>\_testdata\_\<test data version\>.zip
<br><br>
Included files:

- CX_release32_qax_fleet_diagnostic_data-v100_testdata_v100: Test data in one big table structure<br>
Formats: csv, json, parquet, xlsx