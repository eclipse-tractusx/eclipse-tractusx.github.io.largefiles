
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import io.openmanufacturing.sds.aspectmodel.java.customconstraint.FloatMax;
import io.openmanufacturing.sds.aspectmodel.java.customconstraint.FloatMin;
import io.openmanufacturing.sds.aspectmodel.java.exception.EnumAttributeNotFoundException;
import io.openmanufacturing.sds.metamodel.impl.BoundDefinition;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class {@link TypeEnum}.
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum TypeEnum {
	ERROR("Error"), INFO("Info");

	private String value;

	TypeEnum(String value) {
		this.value = value;
	}

	@JsonCreator
	static TypeEnum enumDeserializationConstructor(String value) {
		return fromValue(value).orElseThrow(() -> new EnumAttributeNotFoundException(
				"Tried to parse value \"" + value + "\", but there is no enum field like that in TypeEnum"));
	}

	@JsonValue
	public String getValue() {
		return value;
	}

	public static Optional<TypeEnum> fromValue(String value) {
		return Arrays.stream(TypeEnum.values()).filter(enumValue -> compareEnumValues(enumValue, value)).findAny();
	}

	private static boolean compareEnumValues(TypeEnum enumValue, String value) {
		return enumValue.getValue().equals(value);
	}

}
