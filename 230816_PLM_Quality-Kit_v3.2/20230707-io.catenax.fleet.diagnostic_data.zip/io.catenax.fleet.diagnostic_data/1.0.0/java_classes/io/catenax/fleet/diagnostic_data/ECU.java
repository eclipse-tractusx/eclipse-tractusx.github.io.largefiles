
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for ECU. A single ECU that is present/has a DTC set in the
 * diagnostic session
 */

public class ECU {
	@Pattern(regexp = "^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

	private Optional<String> catenaXId;

	@NotNull
	private String ecuSerialPartNumber;

	@NotNull
	private String name;

	@NotNull
	private String description;

	@NotNull
	private String hwPartNumber;

	@NotNull
	private String hwVersion;

	@NotNull
	private String swPartNumber;

	@NotNull
	private String swVersion;
	private Optional<String> assemblyPartNumber;
	private Optional<String> assemblyPartNumberVersion;

	@NotNull
	private XMLGregorianCalendar readOutDate;

	@JsonCreator
	public ECU(@JsonProperty(value = "catenaXId") Optional<String> catenaXId,
			@JsonProperty(value = "ecuSerialPartNumber") String ecuSerialPartNumber,
			@JsonProperty(value = "name") String name, @JsonProperty(value = "description") String description,
			@JsonProperty(value = "hwPartNumber") String hwPartNumber,
			@JsonProperty(value = "hwVersion") String hwVersion,
			@JsonProperty(value = "swPartNumber") String swPartNumber,
			@JsonProperty(value = "swVersion") String swVersion,
			@JsonProperty(value = "assemblyPartNumber") Optional<String> assemblyPartNumber,
			@JsonProperty(value = "assemblyPartNumberVersion") Optional<String> assemblyPartNumberVersion,
			@JsonProperty(value = "readOutDate") XMLGregorianCalendar readOutDate) {
		super(

		);
		this.catenaXId = catenaXId;
		this.ecuSerialPartNumber = ecuSerialPartNumber;
		this.name = name;
		this.description = description;
		this.hwPartNumber = hwPartNumber;
		this.hwVersion = hwVersion;
		this.swPartNumber = swPartNumber;
		this.swVersion = swVersion;
		this.assemblyPartNumber = assemblyPartNumber;
		this.assemblyPartNumberVersion = assemblyPartNumberVersion;
		this.readOutDate = readOutDate;
	}

	/**
	 * Returns Catena-X Identifier
	 *
	 * @return {@link #catenaXId}
	 */
	public Optional<String> getCatenaXId() {
		return this.catenaXId;
	}

	/**
	 * Returns ECU serial part number
	 *
	 * @return {@link #ecuSerialPartNumber}
	 */
	public String getEcuSerialPartNumber() {
		return this.ecuSerialPartNumber;
	}

	/**
	 * Returns ECU name
	 *
	 * @return {@link #name}
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Returns ECU description
	 *
	 * @return {@link #description}
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Returns ECU HW part number
	 *
	 * @return {@link #hwPartNumber}
	 */
	public String getHwPartNumber() {
		return this.hwPartNumber;
	}

	/**
	 * Returns ECU HW version
	 *
	 * @return {@link #hwVersion}
	 */
	public String getHwVersion() {
		return this.hwVersion;
	}

	/**
	 * Returns ECU SW part number
	 *
	 * @return {@link #swPartNumber}
	 */
	public String getSwPartNumber() {
		return this.swPartNumber;
	}

	/**
	 * Returns ECU SW version
	 *
	 * @return {@link #swVersion}
	 */
	public String getSwVersion() {
		return this.swVersion;
	}

	/**
	 * Returns ECU assembly part number
	 *
	 * @return {@link #assemblyPartNumber}
	 */
	public Optional<String> getAssemblyPartNumber() {
		return this.assemblyPartNumber;
	}

	/**
	 * Returns ECU assembly part number version
	 *
	 * @return {@link #assemblyPartNumberVersion}
	 */
	public Optional<String> getAssemblyPartNumberVersion() {
		return this.assemblyPartNumberVersion;
	}

	/**
	 * Returns Read out date
	 *
	 * @return {@link #readOutDate}
	 */
	public XMLGregorianCalendar getReadOutDate() {
		return this.readOutDate;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final ECU that = (ECU) o;
		return Objects.equals(catenaXId, that.catenaXId)
				&& Objects.equals(ecuSerialPartNumber, that.ecuSerialPartNumber) && Objects.equals(name, that.name)
				&& Objects.equals(description, that.description) && Objects.equals(hwPartNumber, that.hwPartNumber)
				&& Objects.equals(hwVersion, that.hwVersion) && Objects.equals(swPartNumber, that.swPartNumber)
				&& Objects.equals(swVersion, that.swVersion)
				&& Objects.equals(assemblyPartNumber, that.assemblyPartNumber)
				&& Objects.equals(assemblyPartNumberVersion, that.assemblyPartNumberVersion)
				&& Objects.equals(readOutDate, that.readOutDate);
	}

	@Override
	public int hashCode() {
		return Objects.hash(catenaXId, ecuSerialPartNumber, name, description, hwPartNumber, hwVersion, swPartNumber,
				swVersion, assemblyPartNumber, assemblyPartNumberVersion, readOutDate);
	}
}
