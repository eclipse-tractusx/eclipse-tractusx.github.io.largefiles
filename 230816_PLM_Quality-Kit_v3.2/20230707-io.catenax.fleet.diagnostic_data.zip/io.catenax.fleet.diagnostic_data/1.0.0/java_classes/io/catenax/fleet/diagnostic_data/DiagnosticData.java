
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;

/**
 * Generated class for DiagnosticData. data model for vehicle diagnostic data
 * suitable for mass data transfer
 */
public class DiagnosticData implements CollectionAspect<List<DiagnosticSession>, DiagnosticSession> {

	@NotNull
	private List<DiagnosticSession> diagnosticSessions;

	@JsonCreator
	public DiagnosticData(@JsonProperty(value = "diagnosticSessions") List<DiagnosticSession> diagnosticSessions) {
		super(

		);
		this.diagnosticSessions = diagnosticSessions;
	}

	/**
	 * Returns Diagnostic sessions
	 *
	 * @return {@link #diagnosticSessions}
	 */
	public List<DiagnosticSession> getDiagnosticSessions() {
		return this.diagnosticSessions;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final DiagnosticData that = (DiagnosticData) o;
		return Objects.equals(diagnosticSessions, that.diagnosticSessions);
	}

	@Override
	public int hashCode() {
		return Objects.hash(diagnosticSessions);
	}
}
