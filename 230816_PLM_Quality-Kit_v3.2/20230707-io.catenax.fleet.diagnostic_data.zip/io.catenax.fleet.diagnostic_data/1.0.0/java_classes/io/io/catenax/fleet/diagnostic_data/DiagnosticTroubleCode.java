
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for DTC. diagnostic trouble codes or short DTCs are used
 * inside ECUs to monitor failures. They were introduced for measuring vehicle
 * emissions. Major DTCs for emissions are standardized by ISO standard ISO
 * 15031-6:2015 - so called OBD2 standard. Over time DTCs were also introduced
 * in other ECUs also besides engine and emission control. Many DTCs are vehicle
 * manufacturer specific.
 * 
 */

public class DiagnosticTroubleCode {

	@NotNull
	private String ecuSerialPartNumber;
	@Pattern(regexp = "^^[0-9a-fA-F]$")

	private Optional<String> dtcHexValue;

	@NotNull
	@Pattern(regexp = "^[B|C|P|U]{1}[0-9,A-F,a-f]{4}[-]{1}[0-9,A-F,a-f]{2}$")

	private String fullName;

	@NotNull
	private String fullDescription;

	@NotNull
	private XMLGregorianCalendar occurenceDateTime;

	@NotNull
	private String state;
	private Optional<Boolean> isMilOn;

	@NotNull
	private BigInteger occurenceMileage;

	@NotNull
	private String faultPath;

	@NotNull
	private String faultPathDescription;
	private Optional<TypeEnum> type;
	private Optional<Long> occurenceCounterTotal;
	@Pattern(regexp = "^^[0-9a-fA-F]$")

	private Optional<String> freezeFrame;

	@JsonCreator
	public DiagnosticTroubleCode(@JsonProperty(value = "ecuSerialPartNumber") String ecuSerialPartNumber,
			@JsonProperty(value = "dtcHexValue") Optional<String> dtcHexValue,
			@JsonProperty(value = "fullName") String fullName,
			@JsonProperty(value = "fullDescription") String fullDescription,
			@JsonProperty(value = "occurenceDateTime") XMLGregorianCalendar occurenceDateTime,
			@JsonProperty(value = "state") String state, @JsonProperty(value = "isMilOn") Optional<Boolean> isMilOn,
			@JsonProperty(value = "occurenceMileage") BigInteger occurenceMileage,
			@JsonProperty(value = "faultPath") String faultPath,
			@JsonProperty(value = "faultPathDescription") String faultPathDescription,
			@JsonProperty(value = "type") Optional<TypeEnum> type,
			@JsonProperty(value = "occurenceCounterTotal") Optional<Long> occurenceCounterTotal,
			@JsonProperty(value = "freezeFrame") Optional<String> freezeFrame) {
		super(

		);
		this.ecuSerialPartNumber = ecuSerialPartNumber;
		this.dtcHexValue = dtcHexValue;
		this.fullName = fullName;
		this.fullDescription = fullDescription;
		this.occurenceDateTime = occurenceDateTime;
		this.state = state;
		this.isMilOn = isMilOn;
		this.occurenceMileage = occurenceMileage;
		this.faultPath = faultPath;
		this.faultPathDescription = faultPathDescription;
		this.type = type;
		this.occurenceCounterTotal = occurenceCounterTotal;
		this.freezeFrame = freezeFrame;
	}

	/**
	 * Returns ECU serial part number
	 *
	 * @return {@link #ecuSerialPartNumber}
	 */
	public String getEcuSerialPartNumber() {
		return this.ecuSerialPartNumber;
	}

	/**
	 * Returns Hex
	 *
	 * @return {@link #dtcHexValue}
	 */
	public Optional<String> getDtcHexValue() {
		return this.dtcHexValue;
	}

	/**
	 * Returns DTC full name:
	 *
	 * @return {@link #fullName}
	 */
	public String getFullName() {
		return this.fullName;
	}

	/**
	 * Returns DTC description
	 *
	 * @return {@link #fullDescription}
	 */
	public String getFullDescription() {
		return this.fullDescription;
	}

	/**
	 * Returns DTC first occurence
	 *
	 * @return {@link #occurenceDateTime}
	 */
	public XMLGregorianCalendar getOccurenceDateTime() {
		return this.occurenceDateTime;
	}

	/**
	 * Returns DTC state
	 *
	 * @return {@link #state}
	 */
	public String getState() {
		return this.state;
	}

	/**
	 * Returns Is MIL On
	 *
	 * @return {@link #isMilOn}
	 */
	public Optional<Boolean> isIsMilOn() {
		return this.isMilOn;
	}

	/**
	 * Returns DTC first occurence mileage
	 *
	 * @return {@link #occurenceMileage}
	 */
	public BigInteger getOccurenceMileage() {
		return this.occurenceMileage;
	}

	/**
	 * Returns DTC fault path
	 *
	 * @return {@link #faultPath}
	 */
	public String getFaultPath() {
		return this.faultPath;
	}

	/**
	 * Returns DTC fault path description
	 *
	 * @return {@link #faultPathDescription}
	 */
	public String getFaultPathDescription() {
		return this.faultPathDescription;
	}

	/**
	 * Returns Type
	 *
	 * @return {@link #type}
	 */
	public Optional<TypeEnum> getType() {
		return this.type;
	}

	/**
	 * Returns Occurence counter
	 *
	 * @return {@link #occurenceCounterTotal}
	 */
	public Optional<Long> getOccurenceCounterTotal() {
		return this.occurenceCounterTotal;
	}

	/**
	 * Returns DTC freeze frame
	 *
	 * @return {@link #freezeFrame}
	 */
	public Optional<String> getFreezeFrame() {
		return this.freezeFrame;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final DiagnosticTroubleCode that = (DiagnosticTroubleCode) o;
		return Objects.equals(ecuSerialPartNumber, that.ecuSerialPartNumber)
				&& Objects.equals(dtcHexValue, that.dtcHexValue) && Objects.equals(fullName, that.fullName)
				&& Objects.equals(fullDescription, that.fullDescription)
				&& Objects.equals(occurenceDateTime, that.occurenceDateTime) && Objects.equals(state, that.state)
				&& Objects.equals(isMilOn, that.isMilOn) && Objects.equals(occurenceMileage, that.occurenceMileage)
				&& Objects.equals(faultPath, that.faultPath)
				&& Objects.equals(faultPathDescription, that.faultPathDescription) && Objects.equals(type, that.type)
				&& Objects.equals(occurenceCounterTotal, that.occurenceCounterTotal)
				&& Objects.equals(freezeFrame, that.freezeFrame);
	}

	@Override
	public int hashCode() {
		return Objects.hash(ecuSerialPartNumber, dtcHexValue, fullName, fullDescription, occurenceDateTime, state,
				isMilOn, occurenceMileage, faultPath, faultPathDescription, type, occurenceCounterTotal, freezeFrame);
	}
}
