
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Event. If additional information/events are available
 * during this session: This object can be used for calibration information,
 * software updates, ... If this event was measured on vehicle level ->
 * ecuSerialPartNumber is empty
 */

public class Event {

	@NotNull
	private String eventId;

	@NotNull
	private XMLGregorianCalendar eventCreationDate;

	@NotNull
	private String eventDescription;

	@NotNull
	private String eventValue;
	private Optional<String> ecuSerialPartNumber;
	@Pattern(regexp = "^^[0-9a-fA-F]$")

	private Optional<String> dtcHexValue;

	@JsonCreator
	public Event(@JsonProperty(value = "eventId") String eventId,
			@JsonProperty(value = "eventCreationDate") XMLGregorianCalendar eventCreationDate,
			@JsonProperty(value = "eventDescription") String eventDescription,
			@JsonProperty(value = "eventValue") String eventValue,
			@JsonProperty(value = "ecuSerialPartNumber") Optional<String> ecuSerialPartNumber,
			@JsonProperty(value = "dtcHexValue") Optional<String> dtcHexValue) {
		super(

		);
		this.eventId = eventId;
		this.eventCreationDate = eventCreationDate;
		this.eventDescription = eventDescription;
		this.eventValue = eventValue;
		this.ecuSerialPartNumber = ecuSerialPartNumber;
		this.dtcHexValue = dtcHexValue;
	}

	/**
	 * Returns Id
	 *
	 * @return {@link #eventId}
	 */
	public String getEventId() {
		return this.eventId;
	}

	/**
	 * Returns Creation Date
	 *
	 * @return {@link #eventCreationDate}
	 */
	public XMLGregorianCalendar getEventCreationDate() {
		return this.eventCreationDate;
	}

	/**
	 * Returns Description
	 *
	 * @return {@link #eventDescription}
	 */
	public String getEventDescription() {
		return this.eventDescription;
	}

	/**
	 * Returns Value
	 *
	 * @return {@link #eventValue}
	 */
	public String getEventValue() {
		return this.eventValue;
	}

	/**
	 * Returns ECU serial part number
	 *
	 * @return {@link #ecuSerialPartNumber}
	 */
	public Optional<String> getEcuSerialPartNumber() {
		return this.ecuSerialPartNumber;
	}

	/**
	 * Returns Hex
	 *
	 * @return {@link #dtcHexValue}
	 */
	public Optional<String> getDtcHexValue() {
		return this.dtcHexValue;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Event that = (Event) o;
		return Objects.equals(eventId, that.eventId) && Objects.equals(eventCreationDate, that.eventCreationDate)
				&& Objects.equals(eventDescription, that.eventDescription)
				&& Objects.equals(eventValue, that.eventValue)
				&& Objects.equals(ecuSerialPartNumber, that.ecuSerialPartNumber)
				&& Objects.equals(dtcHexValue, that.dtcHexValue);
	}

	@Override
	public int hashCode() {
		return Objects.hash(eventId, eventCreationDate, eventDescription, eventValue, ecuSerialPartNumber, dtcHexValue);
	}
}
