
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Vehicle. all attributes to clearly identify the vehicle
 * during this diagnostic session
 */

public class Vehicle {

	@NotNull
	private String anonymizedVIN;
	@Pattern(regexp = "(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)|(^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)")

	private Optional<String> catenaXId;
	private Optional<String> softwareCategory;
	private Optional<String> softwareVersion;

	@JsonCreator
	public Vehicle(@JsonProperty(value = "anonymizedVIN") String anonymizedVIN,
			@JsonProperty(value = "catenaXId") Optional<String> catenaXId,
			@JsonProperty(value = "softwareCategory") Optional<String> softwareCategory,
			@JsonProperty(value = "softwareVersion") Optional<String> softwareVersion) {
		super(

		);
		this.anonymizedVIN = anonymizedVIN;
		this.catenaXId = catenaXId;
		this.softwareCategory = softwareCategory;
		this.softwareVersion = softwareVersion;
	}

	/**
	 * Returns Anonymized VIN
	 *
	 * @return {@link #anonymizedVIN}
	 */
	public String getAnonymizedVIN() {
		return this.anonymizedVIN;
	}

	/**
	 * Returns Catena-X Identifier
	 *
	 * @return {@link #catenaXId}
	 */
	public Optional<String> getCatenaXId() {
		return this.catenaXId;
	}

	/**
	 * Returns Vehicle software category
	 *
	 * @return {@link #softwareCategory}
	 */
	public Optional<String> getSoftwareCategory() {
		return this.softwareCategory;
	}

	/**
	 * Returns Vehicle software version
	 *
	 * @return {@link #softwareVersion}
	 */
	public Optional<String> getSoftwareVersion() {
		return this.softwareVersion;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Vehicle that = (Vehicle) o;
		return Objects.equals(anonymizedVIN, that.anonymizedVIN) && Objects.equals(catenaXId, that.catenaXId)
				&& Objects.equals(softwareCategory, that.softwareCategory)
				&& Objects.equals(softwareVersion, that.softwareVersion);
	}

	@Override
	public int hashCode() {
		return Objects.hash(anonymizedVIN, catenaXId, softwareCategory, softwareVersion);
	}
}
