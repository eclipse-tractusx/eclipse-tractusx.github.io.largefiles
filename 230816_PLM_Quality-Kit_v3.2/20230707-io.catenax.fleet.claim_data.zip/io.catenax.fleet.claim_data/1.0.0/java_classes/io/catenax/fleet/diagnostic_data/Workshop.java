
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import io.openmanufacturing.sds.aspectmodel.java.customconstraint.FloatMax;
import io.openmanufacturing.sds.aspectmodel.java.customconstraint.FloatMin;
import io.openmanufacturing.sds.metamodel.impl.BoundDefinition;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Workshop. all attributes to clearly identify this
 * workshop
 */

public class Workshop {

	@NotNull
	private String workShopId;
	@Pattern(regexp = "(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)|(^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)")

	private Optional<String> catenaXId;

	@NotNull
	@FloatMin(value = "-90.0", boundDefinition = BoundDefinition.AT_LEAST)
	@FloatMax(value = "90.0", boundDefinition = BoundDefinition.AT_MOST)

	private Float latitude;

	@NotNull
	@FloatMin(value = "-180.0", boundDefinition = BoundDefinition.AT_LEAST)
	@FloatMax(value = "180.0", boundDefinition = BoundDefinition.AT_MOST)

	private Float longitude;

	@JsonCreator
	public Workshop(@JsonProperty(value = "workShopId") String workShopId,
			@JsonProperty(value = "catenaXId") Optional<String> catenaXId,
			@JsonProperty(value = "latitude") Float latitude, @JsonProperty(value = "longitude") Float longitude) {
		super(

		);
		this.workShopId = workShopId;
		this.catenaXId = catenaXId;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	/**
	 * Returns OEM Workshop ID
	 *
	 * @return {@link #workShopId}
	 */
	public String getWorkShopId() {
		return this.workShopId;
	}

	/**
	 * Returns Catena-X Identifier
	 *
	 * @return {@link #catenaXId}
	 */
	public Optional<String> getCatenaXId() {
		return this.catenaXId;
	}

	/**
	 * Returns Latitude
	 *
	 * @return {@link #latitude}
	 */
	public Float getLatitude() {
		return this.latitude;
	}

	/**
	 * Returns Longitude
	 *
	 * @return {@link #longitude}
	 */
	public Float getLongitude() {
		return this.longitude;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Workshop that = (Workshop) o;
		return Objects.equals(workShopId, that.workShopId) && Objects.equals(catenaXId, that.catenaXId)
				&& Objects.equals(latitude, that.latitude) && Objects.equals(longitude, that.longitude);
	}

	@Override
	public int hashCode() {
		return Objects.hash(workShopId, catenaXId, latitude, longitude);
	}
}
