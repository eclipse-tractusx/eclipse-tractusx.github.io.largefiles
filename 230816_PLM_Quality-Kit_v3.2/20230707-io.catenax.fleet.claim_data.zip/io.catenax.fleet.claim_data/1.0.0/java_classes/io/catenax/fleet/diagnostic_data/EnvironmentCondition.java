
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Environment Condition. One environment condition like
 * temperature, rpm,... If the environment condition was measured on vehicle
 * level -> ecuSerialPartNumber is empty
 */

public class EnvironmentCondition {

	@NotNull
	private String conditionId;

	@NotNull
	private XMLGregorianCalendar conditionCreationDate;

	@NotNull
	private String conditionDescription;

	@NotNull
	private Double conditionValue;

	@NotNull
	private String measurementUnit;
	private Optional<String> ecuSerialPartNumber;
	@Pattern(regexp = "(^(0[xX])?[A-Fa-f0-9]+$)")

	private Optional<String> dtcHexValue;

	@JsonCreator
	public EnvironmentCondition(@JsonProperty(value = "conditionId") String conditionId,
			@JsonProperty(value = "conditionCreationDate") XMLGregorianCalendar conditionCreationDate,
			@JsonProperty(value = "conditionDescription") String conditionDescription,
			@JsonProperty(value = "conditionValue") Double conditionValue,
			@JsonProperty(value = "measurementUnit") String measurementUnit,
			@JsonProperty(value = "ecuSerialPartNumber") Optional<String> ecuSerialPartNumber,
			@JsonProperty(value = "dtcHexValue") Optional<String> dtcHexValue) {
		super(

		);
		this.conditionId = conditionId;
		this.conditionCreationDate = conditionCreationDate;
		this.conditionDescription = conditionDescription;
		this.conditionValue = conditionValue;
		this.measurementUnit = measurementUnit;
		this.ecuSerialPartNumber = ecuSerialPartNumber;
		this.dtcHexValue = dtcHexValue;
	}

	/**
	 * Returns Id
	 *
	 * @return {@link #conditionId}
	 */
	public String getConditionId() {
		return this.conditionId;
	}

	/**
	 * Returns Creation Date
	 *
	 * @return {@link #conditionCreationDate}
	 */
	public XMLGregorianCalendar getConditionCreationDate() {
		return this.conditionCreationDate;
	}

	/**
	 * Returns Description
	 *
	 * @return {@link #conditionDescription}
	 */
	public String getConditionDescription() {
		return this.conditionDescription;
	}

	/**
	 * Returns Value
	 *
	 * @return {@link #conditionValue}
	 */
	public Double getConditionValue() {
		return this.conditionValue;
	}

	/**
	 * Returns DTC fault path
	 *
	 * @return {@link #measurementUnit}
	 */
	public String getMeasurementUnit() {
		return this.measurementUnit;
	}

	/**
	 * Returns ECU serial part number
	 *
	 * @return {@link #ecuSerialPartNumber}
	 */
	public Optional<String> getEcuSerialPartNumber() {
		return this.ecuSerialPartNumber;
	}

	/**
	 * Returns Hex
	 *
	 * @return {@link #dtcHexValue}
	 */
	public Optional<String> getDtcHexValue() {
		return this.dtcHexValue;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final EnvironmentCondition that = (EnvironmentCondition) o;
		return Objects.equals(conditionId, that.conditionId)
				&& Objects.equals(conditionCreationDate, that.conditionCreationDate)
				&& Objects.equals(conditionDescription, that.conditionDescription)
				&& Objects.equals(conditionValue, that.conditionValue)
				&& Objects.equals(measurementUnit, that.measurementUnit)
				&& Objects.equals(ecuSerialPartNumber, that.ecuSerialPartNumber)
				&& Objects.equals(dtcHexValue, that.dtcHexValue);
	}

	@Override
	public int hashCode() {
		return Objects.hash(conditionId, conditionCreationDate, conditionDescription, conditionValue, measurementUnit,
				ecuSerialPartNumber, dtcHexValue);
	}
}
