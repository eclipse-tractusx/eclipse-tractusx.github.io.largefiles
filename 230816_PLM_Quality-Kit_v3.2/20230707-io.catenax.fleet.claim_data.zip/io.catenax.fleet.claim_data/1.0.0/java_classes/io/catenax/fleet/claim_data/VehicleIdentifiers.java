
package io.catenax.fleet.claim_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import io.openmanufacturing.sds.metamodel.datatypes.LangString;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Vehicle identifiers. one single vehicle
 */

public class VehicleIdentifiers {
	@Pattern(regexp = "(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)|(^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)")

	private Optional<String> vehicleCatenaXId;

	@NotNull
	private String anonymizedVIN;

	@JsonCreator
	public VehicleIdentifiers(@JsonProperty(value = "vehicleCatenaXId") Optional<String> vehicleCatenaXId,
			@JsonProperty(value = "anonymizedVIN") String anonymizedVIN) {
		super(

		);
		this.vehicleCatenaXId = vehicleCatenaXId;
		this.anonymizedVIN = anonymizedVIN;
	}

	/**
	 * Returns vehicleCatenaXId
	 *
	 * @return {@link #vehicleCatenaXId}
	 */
	public Optional<String> getVehicleCatenaXId() {
		return this.vehicleCatenaXId;
	}

	/**
	 * Returns Anonymized Vin
	 *
	 * @return {@link #anonymizedVIN}
	 */
	public String getAnonymizedVIN() {
		return this.anonymizedVIN;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final VehicleIdentifiers that = (VehicleIdentifiers) o;
		return Objects.equals(vehicleCatenaXId, that.vehicleCatenaXId)
				&& Objects.equals(anonymizedVIN, that.anonymizedVIN);
	}

	@Override
	public int hashCode() {
		return Objects.hash(vehicleCatenaXId, anonymizedVIN);
	}
}
