
package io.catenax.fleet.diagnostic_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for DiagnosticSession. One diagnostic session of one vehicle:
 * Depending on the diagnostic software used in either workshops or over-the-air
 * diagnostics one session can be defined differently: - Workshop diagnostic:
 * Normally for each command to the diagnostic tester is a session diagnostic
 * file created that is later send to the OEM backend system. Examples for one
 * command: Read-out all ECUs with its DTCs or do a Software upgrade of one ECU
 * - Over-the-air: E.g. one diagnostic snapshot is taken after ignition-on
 * 
 * In addition a list of environment conditions can be placed as well as a list
 * of AdditionalInfos.
 * 
 * Both lists are on DiagnosticDataSession level because they can be valid for
 * the whole vehicle(e.g. environment temperature) or only for a specific ECU
 * (e.g. wheel speed sensor at ABS ECU)
 */

public class DiagnosticSession {

	@NotNull
	private XMLGregorianCalendar creationDate;

	@NotNull
	private String sessionId;
	private Optional<String> qualityTaskId;

	@NotNull
	@Pattern(regexp = "^[A-Z][A-Z][A-Z]$")

	private String countryCode;

	@NotNull
	private BigInteger mileage;

	@NotNull
	private Vehicle vehicle;
	private Optional<Workshop> workshop;

	@NotNull
	private List<ECU> ecuList;
	private Optional<List<DiagnosticTroubleCode>> dtcList;
	private Optional<List<EnvironmentCondition>> envConditionList;
	private Optional<List<Event>> eventList;

	@JsonCreator
	public DiagnosticSession(@JsonProperty(value = "creationDate") XMLGregorianCalendar creationDate,
			@JsonProperty(value = "sessionId") String sessionId,
			@JsonProperty(value = "qualityTaskId") Optional<String> qualityTaskId,
			@JsonProperty(value = "countryCode") String countryCode,
			@JsonProperty(value = "mileage") BigInteger mileage, @JsonProperty(value = "vehicle") Vehicle vehicle,
			@JsonProperty(value = "workshop") Optional<Workshop> workshop,
			@JsonProperty(value = "ecuList") List<ECU> ecuList,
			@JsonProperty(value = "dtcList") Optional<List<DiagnosticTroubleCode>> dtcList,
			@JsonProperty(value = "envConditionList") Optional<List<EnvironmentCondition>> envConditionList,
			@JsonProperty(value = "eventList") Optional<List<Event>> eventList) {
		super(

		);
		this.creationDate = creationDate;
		this.sessionId = sessionId;
		this.qualityTaskId = qualityTaskId;
		this.countryCode = countryCode;
		this.mileage = mileage;
		this.vehicle = vehicle;
		this.workshop = workshop;
		this.ecuList = ecuList;
		this.dtcList = dtcList;
		this.envConditionList = envConditionList;
		this.eventList = eventList;
	}

	/**
	 * Returns Creationdate
	 *
	 * @return {@link #creationDate}
	 */
	public XMLGregorianCalendar getCreationDate() {
		return this.creationDate;
	}

	/**
	 * Returns Session identifier
	 *
	 * @return {@link #sessionId}
	 */
	public String getSessionId() {
		return this.sessionId;
	}

	/**
	 * Returns Quality Task ID
	 *
	 * @return {@link #qualityTaskId}
	 */
	public Optional<String> getQualityTaskId() {
		return this.qualityTaskId;
	}

	/**
	 * Returns Country Code
	 *
	 * @return {@link #countryCode}
	 */
	public String getCountryCode() {
		return this.countryCode;
	}

	/**
	 * Returns Session mileage
	 *
	 * @return {@link #mileage}
	 */
	public BigInteger getMileage() {
		return this.mileage;
	}

	/**
	 * Returns vehicle
	 *
	 * @return {@link #vehicle}
	 */
	public Vehicle getVehicle() {
		return this.vehicle;
	}

	/**
	 * Returns workshop
	 *
	 * @return {@link #workshop}
	 */
	public Optional<Workshop> getWorkshop() {
		return this.workshop;
	}

	/**
	 * Returns ECU list
	 *
	 * @return {@link #ecuList}
	 */
	public List<ECU> getEcuList() {
		return this.ecuList;
	}

	/**
	 * Returns dtcList
	 *
	 * @return {@link #dtcList}
	 */
	public Optional<List<DiagnosticTroubleCode>> getDtcList() {
		return this.dtcList;
	}

	/**
	 * Returns Environment Conditions
	 *
	 * @return {@link #envConditionList}
	 */
	public Optional<List<EnvironmentCondition>> getEnvConditionList() {
		return this.envConditionList;
	}

	/**
	 * Returns Events
	 *
	 * @return {@link #eventList}
	 */
	public Optional<List<Event>> getEventList() {
		return this.eventList;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final DiagnosticSession that = (DiagnosticSession) o;
		return Objects.equals(creationDate, that.creationDate) && Objects.equals(sessionId, that.sessionId)
				&& Objects.equals(qualityTaskId, that.qualityTaskId) && Objects.equals(countryCode, that.countryCode)
				&& Objects.equals(mileage, that.mileage) && Objects.equals(vehicle, that.vehicle)
				&& Objects.equals(workshop, that.workshop) && Objects.equals(ecuList, that.ecuList)
				&& Objects.equals(dtcList, that.dtcList) && Objects.equals(envConditionList, that.envConditionList)
				&& Objects.equals(eventList, that.eventList);
	}

	@Override
	public int hashCode() {
		return Objects.hash(creationDate, sessionId, qualityTaskId, countryCode, mileage, vehicle, workshop, ecuList,
				dtcList, envConditionList, eventList);
	}
}
