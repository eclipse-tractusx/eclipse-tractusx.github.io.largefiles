
package io.catenax.fleet.claim_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import io.openmanufacturing.sds.metamodel.datatypes.LangString;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Part. one specific part
 */

public class ClaimedPart {

	@NotNull
	private Boolean isPartReplaced;

	@NotNull
	private Boolean isPartCausal;
	private Optional<BigInteger> amountOfReplacedParts;

	@NotNull
	private Part replacedPart;

	@NotNull
	private Part sparePart;

	@JsonCreator
	public ClaimedPart(@JsonProperty(value = "isPartReplaced") Boolean isPartReplaced,
			@JsonProperty(value = "isPartCausal") Boolean isPartCausal,
			@JsonProperty(value = "amountOfReplacedParts") Optional<BigInteger> amountOfReplacedParts,
			@JsonProperty(value = "replacedPart") Part replacedPart,
			@JsonProperty(value = "sparePart") Part sparePart) {
		super(

		);
		this.isPartReplaced = isPartReplaced;
		this.isPartCausal = isPartCausal;
		this.amountOfReplacedParts = amountOfReplacedParts;
		this.replacedPart = replacedPart;
		this.sparePart = sparePart;
	}

	/**
	 * Returns IsPartReplaced
	 *
	 * @return {@link #isPartReplaced}
	 */
	public Boolean isIsPartReplaced() {
		return this.isPartReplaced;
	}

	/**
	 * Returns IsPartCausal
	 *
	 * @return {@link #isPartCausal}
	 */
	public Boolean isIsPartCausal() {
		return this.isPartCausal;
	}

	/**
	 * Returns AmountOfReplacedParts
	 *
	 * @return {@link #amountOfReplacedParts}
	 */
	public Optional<BigInteger> getAmountOfReplacedParts() {
		return this.amountOfReplacedParts;
	}

	/**
	 * Returns ReplacedPart
	 *
	 * @return {@link #replacedPart}
	 */
	public Part getReplacedPart() {
		return this.replacedPart;
	}

	/**
	 * Returns Spare Part
	 *
	 * @return {@link #sparePart}
	 */
	public Part getSparePart() {
		return this.sparePart;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final ClaimedPart that = (ClaimedPart) o;
		return Objects.equals(isPartReplaced, that.isPartReplaced) && Objects.equals(isPartCausal, that.isPartCausal)
				&& Objects.equals(amountOfReplacedParts, that.amountOfReplacedParts)
				&& Objects.equals(replacedPart, that.replacedPart) && Objects.equals(sparePart, that.sparePart);
	}

	@Override
	public int hashCode() {
		return Objects.hash(isPartReplaced, isPartCausal, amountOfReplacedParts, replacedPart, sparePart);
	}
}
