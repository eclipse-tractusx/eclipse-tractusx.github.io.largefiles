
package io.catenax.fleet.claim_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import io.openmanufacturing.sds.metamodel.datatypes.LangString;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Text. everything to describe a claim
 */

public class Claim {
	private Optional<List<String>> listOfDiagnosticSessionId;

	@NotNull
	private BigInteger repairMileage;

	@NotNull
	private XMLGregorianCalendar repairDate;

	@NotNull
	private LangString technicianComment;
	private Optional<LangString> customerComment;

	@NotNull
	private String claimId;

	@NotNull
	private VehicleIdentifiers vehicleIdentifiers;

	@NotNull
	private ClaimedPart listOfParts;

	@NotNull
	private String qualityTaskId;
	private Optional<String> damageCode;

	@JsonCreator
	public Claim(@JsonProperty(value = "listOfDiagnosticSessionId") Optional<List<String>> listOfDiagnosticSessionId,
			@JsonProperty(value = "repairMileage") BigInteger repairMileage,
			@JsonProperty(value = "repairDate") XMLGregorianCalendar repairDate,
			@JsonProperty(value = "technicianComment") LangString technicianComment,
			@JsonProperty(value = "customerComment") Optional<LangString> customerComment,
			@JsonProperty(value = "claimId") String claimId,
			@JsonProperty(value = "vehicleIdentifiers") VehicleIdentifiers vehicleIdentifiers,
			@JsonProperty(value = "listOfParts") ClaimedPart listOfParts,
			@JsonProperty(value = "qualityTaskId") String qualityTaskId,
			@JsonProperty(value = "damageCode") Optional<String> damageCode) {
		super(

		);
		this.listOfDiagnosticSessionId = listOfDiagnosticSessionId;
		this.repairMileage = repairMileage;
		this.repairDate = repairDate;
		this.technicianComment = technicianComment;
		this.customerComment = customerComment;
		this.claimId = claimId;
		this.vehicleIdentifiers = vehicleIdentifiers;
		this.listOfParts = listOfParts;
		this.qualityTaskId = qualityTaskId;
		this.damageCode = damageCode;
	}

	/**
	 * Returns ListOfDiagnosticSessionId
	 *
	 * @return {@link #listOfDiagnosticSessionId}
	 */
	public Optional<List<String>> getListOfDiagnosticSessionId() {
		return this.listOfDiagnosticSessionId;
	}

	/**
	 * Returns Repair mileage
	 *
	 * @return {@link #repairMileage}
	 */
	public BigInteger getRepairMileage() {
		return this.repairMileage;
	}

	/**
	 * Returns RepairDate
	 *
	 * @return {@link #repairDate}
	 */
	public XMLGregorianCalendar getRepairDate() {
		return this.repairDate;
	}

	/**
	 * Returns TechnicianComment
	 *
	 * @return {@link #technicianComment}
	 */
	public LangString getTechnicianComment() {
		return this.technicianComment;
	}

	/**
	 * Returns CustomerComment
	 *
	 * @return {@link #customerComment}
	 */
	public Optional<LangString> getCustomerComment() {
		return this.customerComment;
	}

	/**
	 * Returns ClaimID
	 *
	 * @return {@link #claimId}
	 */
	public String getClaimId() {
		return this.claimId;
	}

	/**
	 * Returns vehicle identifiers
	 *
	 * @return {@link #vehicleIdentifiers}
	 */
	public VehicleIdentifiers getVehicleIdentifiers() {
		return this.vehicleIdentifiers;
	}

	/**
	 * Returns ListOfParts
	 *
	 * @return {@link #listOfParts}
	 */
	public ClaimedPart getListOfParts() {
		return this.listOfParts;
	}

	/**
	 * Returns QualityTaskID
	 *
	 * @return {@link #qualityTaskId}
	 */
	public String getQualityTaskId() {
		return this.qualityTaskId;
	}

	/**
	 * Returns DamageCode
	 *
	 * @return {@link #damageCode}
	 */
	public Optional<String> getDamageCode() {
		return this.damageCode;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Claim that = (Claim) o;
		return Objects.equals(listOfDiagnosticSessionId, that.listOfDiagnosticSessionId)
				&& Objects.equals(repairMileage, that.repairMileage) && Objects.equals(repairDate, that.repairDate)
				&& Objects.equals(technicianComment, that.technicianComment)
				&& Objects.equals(customerComment, that.customerComment) && Objects.equals(claimId, that.claimId)
				&& Objects.equals(vehicleIdentifiers, that.vehicleIdentifiers)
				&& Objects.equals(listOfParts, that.listOfParts) && Objects.equals(qualityTaskId, that.qualityTaskId)
				&& Objects.equals(damageCode, that.damageCode);
	}

	@Override
	public int hashCode() {
		return Objects.hash(listOfDiagnosticSessionId, repairMileage, repairDate, technicianComment, customerComment,
				claimId, vehicleIdentifiers, listOfParts, qualityTaskId, damageCode);
	}
}
