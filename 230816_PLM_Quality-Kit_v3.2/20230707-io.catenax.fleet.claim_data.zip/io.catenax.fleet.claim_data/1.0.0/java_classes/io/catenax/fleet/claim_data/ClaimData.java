
package io.catenax.fleet.claim_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;

/**
 * Generated class for ClaimData. Claim data from a fleet
 */
public class ClaimData implements CollectionAspect<List<Claim>, Claim> {

	@NotNull
	private List<Claim> listOfClaims;

	@JsonCreator
	public ClaimData(@JsonProperty(value = "listOfClaims") List<Claim> listOfClaims) {
		super(

		);
		this.listOfClaims = listOfClaims;
	}

	/**
	 * Returns listOfClaims
	 *
	 * @return {@link #listOfClaims}
	 */
	public List<Claim> getListOfClaims() {
		return this.listOfClaims;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final ClaimData that = (ClaimData) o;
		return Objects.equals(listOfClaims, that.listOfClaims);
	}

	@Override
	public int hashCode() {
		return Objects.hash(listOfClaims);
	}
}
