
package io.catenax.fleet.claim_data;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import io.openmanufacturing.sds.metamodel.datatypes.LangString;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Part. a generic description of part of the car
 */

public class Part {

	@NotNull
	private String number;

	@NotNull
	private String name;
	private Optional<String> serialNumber;
	@Pattern(regexp = "(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)|(^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)")

	private Optional<String> catenaXId;
	private Optional<String> supplierId;

	@JsonCreator
	public Part(@JsonProperty(value = "number") String number, @JsonProperty(value = "name") String name,
			@JsonProperty(value = "serialNumber") Optional<String> serialNumber,
			@JsonProperty(value = "catenaXId") Optional<String> catenaXId,
			@JsonProperty(value = "supplierId") Optional<String> supplierId) {
		super(

		);
		this.number = number;
		this.name = name;
		this.serialNumber = serialNumber;
		this.catenaXId = catenaXId;
		this.supplierId = supplierId;
	}

	/**
	 * Returns Number
	 *
	 * @return {@link #number}
	 */
	public String getNumber() {
		return this.number;
	}

	/**
	 * Returns Name
	 *
	 * @return {@link #name}
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Returns SerialNumber
	 *
	 * @return {@link #serialNumber}
	 */
	public Optional<String> getSerialNumber() {
		return this.serialNumber;
	}

	/**
	 * Returns Catena-X Identifier
	 *
	 * @return {@link #catenaXId}
	 */
	public Optional<String> getCatenaXId() {
		return this.catenaXId;
	}

	/**
	 * Returns SupplierID
	 *
	 * @return {@link #supplierId}
	 */
	public Optional<String> getSupplierId() {
		return this.supplierId;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Part that = (Part) o;
		return Objects.equals(number, that.number) && Objects.equals(name, that.name)
				&& Objects.equals(serialNumber, that.serialNumber) && Objects.equals(catenaXId, that.catenaXId)
				&& Objects.equals(supplierId, that.supplierId);
	}

	@Override
	public int hashCode() {
		return Objects.hash(number, name, serialNumber, catenaXId, supplierId);
	}
}
