
package io.catenax.quality_task;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for Company. One company involved in this qTask
 */

public class Company {

	@NotNull
	private String cxBPN;

	@NotNull
	private String name;

	@NotNull
	@Pattern(regexp = "^[a-zA-Z0-9.!#$%&\u2019*+\\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$")

	private String email;

	@JsonCreator
	public Company(@JsonProperty(value = "cxBPN") String cxBPN, @JsonProperty(value = "name") String name,
			@JsonProperty(value = "email") String email) {
		super(

		);
		this.cxBPN = cxBPN;
		this.name = name;
		this.email = email;
	}

	/**
	 * Returns CX Business partner number
	 *
	 * @return {@link #cxBPN}
	 */
	public String getCxBPN() {
		return this.cxBPN;
	}

	/**
	 * Returns Company name
	 *
	 * @return {@link #name}
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Returns email
	 *
	 * @return {@link #email}
	 */
	public String getEmail() {
		return this.email;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Company that = (Company) o;
		return Objects.equals(cxBPN, that.cxBPN) && Objects.equals(name, that.name)
				&& Objects.equals(email, that.email);
	}

	@Override
	public int hashCode() {
		return Objects.hash(cxBPN, name, email);
	}
}
