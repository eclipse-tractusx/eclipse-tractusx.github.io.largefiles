
package io.catenax.quality_task;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.openmanufacturing.sds.aspectmodel.java.CollectionAspect;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Generated class for QualityTask. A quality task (qTask) defines why data is
 * exchanged between 2 or more companies and what insights should be generated
 * out of the transferred data. In addition there is a flag, what happens with
 * the transferred data when this qTask is closed
 */
public class QualityTask implements CollectionAspect<List<Company>, Company> {

	@NotNull
	private String qualityTaskId;

	@NotNull
	private StatusCharacteristic status;

	@NotNull
	private XMLGregorianCalendar creationDate;

	@NotNull
	private String title;

	@NotNull
	private String description;

	@NotNull
	private String component;

	@NotNull
	private DataDeletionEnumeration dataDeletion;

	@NotNull
	private List<Company> listOfCompanies;

	@JsonCreator
	public QualityTask(@JsonProperty(value = "qualityTaskId") String qualityTaskId,
			@JsonProperty(value = "status") StatusCharacteristic status,
			@JsonProperty(value = "creationDate") XMLGregorianCalendar creationDate,
			@JsonProperty(value = "title") String title, @JsonProperty(value = "description") String description,
			@JsonProperty(value = "component") String component,
			@JsonProperty(value = "dataDeletion") DataDeletionEnumeration dataDeletion,
			@JsonProperty(value = "listOfCompanies") List<Company> listOfCompanies) {
		super(

		);
		this.qualityTaskId = qualityTaskId;
		this.status = status;
		this.creationDate = creationDate;
		this.title = title;
		this.description = description;
		this.component = component;
		this.dataDeletion = dataDeletion;
		this.listOfCompanies = listOfCompanies;
	}

	/**
	 * Returns q-Task ID
	 *
	 * @return {@link #qualityTaskId}
	 */
	public String getQualityTaskId() {
		return this.qualityTaskId;
	}

	/**
	 * Returns Status
	 *
	 * @return {@link #status}
	 */
	public StatusCharacteristic getStatus() {
		return this.status;
	}

	/**
	 * Returns Creation Date
	 *
	 * @return {@link #creationDate}
	 */
	public XMLGregorianCalendar getCreationDate() {
		return this.creationDate;
	}

	/**
	 * Returns Title
	 *
	 * @return {@link #title}
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * Returns Description
	 *
	 * @return {@link #description}
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Returns Component
	 *
	 * @return {@link #component}
	 */
	public String getComponent() {
		return this.component;
	}

	/**
	 * Returns Deletion policy
	 *
	 * @return {@link #dataDeletion}
	 */
	public DataDeletionEnumeration getDataDeletion() {
		return this.dataDeletion;
	}

	/**
	 * Returns List of companies
	 *
	 * @return {@link #listOfCompanies}
	 */
	public List<Company> getListOfCompanies() {
		return this.listOfCompanies;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final QualityTask that = (QualityTask) o;
		return Objects.equals(qualityTaskId, that.qualityTaskId) && Objects.equals(status, that.status)
				&& Objects.equals(creationDate, that.creationDate) && Objects.equals(title, that.title)
				&& Objects.equals(description, that.description) && Objects.equals(component, that.component)
				&& Objects.equals(dataDeletion, that.dataDeletion)
				&& Objects.equals(listOfCompanies, that.listOfCompanies);
	}

	@Override
	public int hashCode() {
		return Objects.hash(qualityTaskId, status, creationDate, title, description, component, dataDeletion,
				listOfCompanies);
	}
}
