
package io.catenax.parts_analyses;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;

/**
 * Generated class for Additional information. One key:value information pair
 */

public class AdditionalInformation {

	@NotNull
	private List<String> keys;

	@NotNull
	private List<String> value;

	@JsonCreator
	public AdditionalInformation(@JsonProperty(value = "keys") List<String> keys,
			@JsonProperty(value = "value") List<String> value) {
		super(

		);
		this.keys = keys;
		this.value = value;
	}

	/**
	 * Returns Keys
	 *
	 * @return {@link #keys}
	 */
	public List<String> getKeys() {
		return this.keys;
	}

	/**
	 * Returns Value
	 *
	 * @return {@link #value}
	 */
	public List<String> getValue() {
		return this.value;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final AdditionalInformation that = (AdditionalInformation) o;
		return Objects.equals(keys, that.keys) && Objects.equals(value, that.value);
	}

	@Override
	public int hashCode() {
		return Objects.hash(keys, value);
	}
}
