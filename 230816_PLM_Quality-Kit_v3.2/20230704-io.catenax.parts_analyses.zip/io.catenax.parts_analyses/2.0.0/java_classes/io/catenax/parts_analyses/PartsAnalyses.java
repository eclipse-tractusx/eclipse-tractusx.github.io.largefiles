
package io.catenax.parts_analyses;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;

/**
 * Generated class for Parts Analysis. Parts analysis that are related to one
 * quality task
 */
public class PartsAnalyses implements CollectionAspect<List<PartAnalysis>, PartAnalysis> {

	@NotNull
	private List<PartAnalysis> listOfPartAnalyses;

	@JsonCreator
	public PartsAnalyses(@JsonProperty(value = "listOfPartAnalyses") List<PartAnalysis> listOfPartAnalyses) {
		super(

		);
		this.listOfPartAnalyses = listOfPartAnalyses;
	}

	/**
	 * Returns List Of several Part Analyses
	 *
	 * @return {@link #listOfPartAnalyses}
	 */
	public List<PartAnalysis> getListOfPartAnalyses() {
		return this.listOfPartAnalyses;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final PartsAnalyses that = (PartsAnalyses) o;
		return Objects.equals(listOfPartAnalyses, that.listOfPartAnalyses);
	}

	@Override
	public int hashCode() {
		return Objects.hash(listOfPartAnalyses);
	}
}
