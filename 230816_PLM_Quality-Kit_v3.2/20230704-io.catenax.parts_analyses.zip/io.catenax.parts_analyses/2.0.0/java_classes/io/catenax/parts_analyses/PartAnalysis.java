
package io.catenax.parts_analyses;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;

/**
 * Generated class for Part Analysis. The analysis results of ONE part
 */

public class PartAnalysis {

	@NotNull
	private String manufacturerAnalysisID;

	@NotNull
	private String qualityTaskId;

	@NotNull
	private String anonymizedVin;

	@NotNull
	private StatusCharacteristic status;

	@NotNull
	private Boolean isDefect;

	@NotNull
	private String resultsDescription;

	@NotNull
	private String manufacturerSerialPartNumber;

	@NotNull
	private String manufacturerPartNumber;

	@NotNull
	private String manufacturerPartName;
	@Pattern(regexp = "(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)|(^urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)")

	private Optional<String> catenaXPartId;
	private Optional<String> customerAnalysisID;
	private Optional<String> customerPartNumber;
	private Optional<List<AdditionalInformation>> addtionalInformation;

	@JsonCreator
	public PartAnalysis(@JsonProperty(value = "manufacturerAnalysisID") String manufacturerAnalysisID,
			@JsonProperty(value = "qualityTaskId") String qualityTaskId,
			@JsonProperty(value = "anonymizedVin") String anonymizedVin,
			@JsonProperty(value = "status") StatusCharacteristic status,
			@JsonProperty(value = "isDefect") Boolean isDefect,
			@JsonProperty(value = "resultsDescription") String resultsDescription,
			@JsonProperty(value = "manufacturerSerialPartNumber") String manufacturerSerialPartNumber,
			@JsonProperty(value = "manufacturerPartNumber") String manufacturerPartNumber,
			@JsonProperty(value = "manufacturerPartName") String manufacturerPartName,
			@JsonProperty(value = "catenaXPartId") Optional<String> catenaXPartId,
			@JsonProperty(value = "customerAnalysisID") Optional<String> customerAnalysisID,
			@JsonProperty(value = "customerPartNumber") Optional<String> customerPartNumber,
			@JsonProperty(value = "addtionalInformation") Optional<List<AdditionalInformation>> addtionalInformation) {
		super(

		);
		this.manufacturerAnalysisID = manufacturerAnalysisID;
		this.qualityTaskId = qualityTaskId;
		this.anonymizedVin = anonymizedVin;
		this.status = status;
		this.isDefect = isDefect;
		this.resultsDescription = resultsDescription;
		this.manufacturerSerialPartNumber = manufacturerSerialPartNumber;
		this.manufacturerPartNumber = manufacturerPartNumber;
		this.manufacturerPartName = manufacturerPartName;
		this.catenaXPartId = catenaXPartId;
		this.customerAnalysisID = customerAnalysisID;
		this.customerPartNumber = customerPartNumber;
		this.addtionalInformation = addtionalInformation;
	}

	/**
	 * Returns Manufacturer Analysis ID
	 *
	 * @return {@link #manufacturerAnalysisID}
	 */
	public String getManufacturerAnalysisID() {
		return this.manufacturerAnalysisID;
	}

	/**
	 * Returns Quality Task ID
	 *
	 * @return {@link #qualityTaskId}
	 */
	public String getQualityTaskId() {
		return this.qualityTaskId;
	}

	/**
	 * Returns Anonymized VIN
	 *
	 * @return {@link #anonymizedVin}
	 */
	public String getAnonymizedVin() {
		return this.anonymizedVin;
	}

	/**
	 * Returns Status
	 *
	 * @return {@link #status}
	 */
	public StatusCharacteristic getStatus() {
		return this.status;
	}

	/**
	 * Returns Part defect flag
	 *
	 * @return {@link #isDefect}
	 */
	public Boolean isIsDefect() {
		return this.isDefect;
	}

	/**
	 * Returns Several results of analysis
	 *
	 * @return {@link #resultsDescription}
	 */
	public String getResultsDescription() {
		return this.resultsDescription;
	}

	/**
	 * Returns Manufacturer serial part number
	 *
	 * @return {@link #manufacturerSerialPartNumber}
	 */
	public String getManufacturerSerialPartNumber() {
		return this.manufacturerSerialPartNumber;
	}

	/**
	 * Returns Manufacturer Part Number
	 *
	 * @return {@link #manufacturerPartNumber}
	 */
	public String getManufacturerPartNumber() {
		return this.manufacturerPartNumber;
	}

	/**
	 * Returns Manufacturer part name
	 *
	 * @return {@link #manufacturerPartName}
	 */
	public String getManufacturerPartName() {
		return this.manufacturerPartName;
	}

	/**
	 * Returns Catena-X Part ID
	 *
	 * @return {@link #catenaXPartId}
	 */
	public Optional<String> getCatenaXPartId() {
		return this.catenaXPartId;
	}

	/**
	 * Returns Customer Analysis ID
	 *
	 * @return {@link #customerAnalysisID}
	 */
	public Optional<String> getCustomerAnalysisID() {
		return this.customerAnalysisID;
	}

	/**
	 * Returns Customer part number
	 *
	 * @return {@link #customerPartNumber}
	 */
	public Optional<String> getCustomerPartNumber() {
		return this.customerPartNumber;
	}

	/**
	 * Returns Additional information
	 *
	 * @return {@link #addtionalInformation}
	 */
	public Optional<List<AdditionalInformation>> getAddtionalInformation() {
		return this.addtionalInformation;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final PartAnalysis that = (PartAnalysis) o;
		return Objects.equals(manufacturerAnalysisID, that.manufacturerAnalysisID)
				&& Objects.equals(qualityTaskId, that.qualityTaskId)
				&& Objects.equals(anonymizedVin, that.anonymizedVin) && Objects.equals(status, that.status)
				&& Objects.equals(isDefect, that.isDefect)
				&& Objects.equals(resultsDescription, that.resultsDescription)
				&& Objects.equals(manufacturerSerialPartNumber, that.manufacturerSerialPartNumber)
				&& Objects.equals(manufacturerPartNumber, that.manufacturerPartNumber)
				&& Objects.equals(manufacturerPartName, that.manufacturerPartName)
				&& Objects.equals(catenaXPartId, that.catenaXPartId)
				&& Objects.equals(customerAnalysisID, that.customerAnalysisID)
				&& Objects.equals(customerPartNumber, that.customerPartNumber)
				&& Objects.equals(addtionalInformation, that.addtionalInformation);
	}

	@Override
	public int hashCode() {
		return Objects.hash(manufacturerAnalysisID, qualityTaskId, anonymizedVin, status, isDefect, resultsDescription,
				manufacturerSerialPartNumber, manufacturerPartNumber, manufacturerPartName, catenaXPartId,
				customerAnalysisID, customerPartNumber, addtionalInformation);
	}
}
