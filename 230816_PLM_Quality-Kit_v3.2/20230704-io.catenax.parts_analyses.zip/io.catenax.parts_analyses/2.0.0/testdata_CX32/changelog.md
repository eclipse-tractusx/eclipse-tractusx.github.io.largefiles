# PartsAnalyses 2.0.0: Test data generation

## General hint
- columns in test data are now in aphabetical order (besides foreign key -> this is always in the beginning)
- Correct UUIDs are now used for all Catena-X IDs 
- json test data is compliant with json_Schema

## Adaption test data from CX release 3.0, model PartAnalyses 1.0.0

| column      | Modification |
| ----------- | ----------- |
|anonymizedVIN| merged from claim test data of CX release 3.0|
|catenaXIdentifier|renamed to catenaXPartId|
|manufacturerPartIdentifier|renamed tomanufacturerPartNumber|
|customerPartIdentifier|renamed to customerPartNumber|
|nameAtManufacturer|renamed to manufacturerPartName|

## Added data to fit model PartsAnalyses 2.0.0
- Created new data for addtionalInformation entity
- Added customerAnalysisID,manufacturerAnalysisID poperty to fit new data model structure

## Content test data files CX release 3.2
Naming convention for test data zip container: <br>
CX_\<Catena-X release number\>\_\<aspect model\>\_\<aspect model version\>\_testdata\_\<test data version\>.zip
<br><br>
Included files:

- CX_release32_partsanalyses_200_testdata_100 in one file. <br>
Properties from child entities are now stored as JSON array --> Same structure in every file<br>
Formats: csv, json, parquet, xlsx

- PartsAnalyses.listOfPartAnalyses: Normalized test data: Only properties of root entity.<br> 
Formats: csv, parquet, xlsx

- PartsAnalyses.listOfPartAnalyses.addtionalInformation: Normalized test data: Only properties of entity addtionalInformation + foreignKey manufacturerAnalysisID <br>
Formats: csv, parquet, xlsx