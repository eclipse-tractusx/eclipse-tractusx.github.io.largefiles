
package io.catenax.quality_task_attachment;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;
import org.eclipse.esmf.metamodel.datatypes.Curie;

/**
 * Generated class for VariableAttribute. A list describing the variables
 * contained in the file
 */

public class VariableAttribute {

	@NotNull
	private String variableName;

	@NotNull
	private String dataType;

	@NotNull
	private Curie unit;
	private Optional<String> variableDescription;

	@JsonCreator
	public VariableAttribute(@JsonProperty(value = "variableName") String variableName,
			@JsonProperty(value = "dataType") String dataType, @JsonProperty(value = "unit") Curie unit,
			@JsonProperty(value = "variableDescription") Optional<String> variableDescription) {
		super(

		);
		this.variableName = variableName;
		this.dataType = dataType;
		this.unit = unit;
		this.variableDescription = variableDescription;
	}

	/**
	 * Returns Variable name
	 *
	 * @return {@link #variableName}
	 */
	public String getVariableName() {
		return this.variableName;
	}

	/**
	 * Returns Variable data type
	 *
	 * @return {@link #dataType}
	 */
	public String getDataType() {
		return this.dataType;
	}

	/**
	 * Returns Unit
	 *
	 * @return {@link #unit}
	 */
	public Curie getUnit() {
		return this.unit;
	}

	/**
	 * Returns Variable description
	 *
	 * @return {@link #variableDescription}
	 */
	public Optional<String> getVariableDescription() {
		return this.variableDescription;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final VariableAttribute that = (VariableAttribute) o;
		return Objects.equals(variableName, that.variableName) && Objects.equals(dataType, that.dataType)
				&& Objects.equals(unit, that.unit) && Objects.equals(variableDescription, that.variableDescription);
	}

	@Override
	public int hashCode() {
		return Objects.hash(variableName, dataType, unit, variableDescription);
	}
}
