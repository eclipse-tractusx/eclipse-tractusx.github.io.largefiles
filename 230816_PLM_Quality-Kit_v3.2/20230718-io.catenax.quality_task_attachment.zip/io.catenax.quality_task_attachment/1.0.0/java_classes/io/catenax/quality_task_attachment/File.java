
package io.catenax.quality_task_attachment;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;

/**
 * Generated class for File. One file attached to the quality task
 */

public class File {

	@NotNull
	private String fileName;
	private Optional<SchemaDefinition> schema;

	@NotNull
	private String filePath;

	@NotNull
	private BigInteger sizeInKb;

	@NotNull
	private String fileDescription;

	@NotNull
	private String fileExtension;

	@JsonCreator
	public File(@JsonProperty(value = "fileName") String fileName,
			@JsonProperty(value = "schema") Optional<SchemaDefinition> schema,
			@JsonProperty(value = "filePath") String filePath, @JsonProperty(value = "sizeInKb") BigInteger sizeInKb,
			@JsonProperty(value = "fileDescription") String fileDescription,
			@JsonProperty(value = "fileExtension") String fileExtension) {
		super(

		);
		this.fileName = fileName;
		this.schema = schema;
		this.filePath = filePath;
		this.sizeInKb = sizeInKb;
		this.fileDescription = fileDescription;
		this.fileExtension = fileExtension;
	}

	/**
	 * Returns file name
	 *
	 * @return {@link #fileName}
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * Returns schema
	 *
	 * @return {@link #schema}
	 */
	public Optional<SchemaDefinition> getSchema() {
		return this.schema;
	}

	/**
	 * Returns File Path
	 *
	 * @return {@link #filePath}
	 */
	public String getFilePath() {
		return this.filePath;
	}

	/**
	 * Returns Size in Kilobyte
	 *
	 * @return {@link #sizeInKb}
	 */
	public BigInteger getSizeInKb() {
		return this.sizeInKb;
	}

	/**
	 * Returns File Description
	 *
	 * @return {@link #fileDescription}
	 */
	public String getFileDescription() {
		return this.fileDescription;
	}

	/**
	 * Returns File Extension
	 *
	 * @return {@link #fileExtension}
	 */
	public String getFileExtension() {
		return this.fileExtension;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final File that = (File) o;
		return Objects.equals(fileName, that.fileName) && Objects.equals(schema, that.schema)
				&& Objects.equals(filePath, that.filePath) && Objects.equals(sizeInKb, that.sizeInKb)
				&& Objects.equals(fileDescription, that.fileDescription)
				&& Objects.equals(fileExtension, that.fileExtension);
	}

	@Override
	public int hashCode() {
		return Objects.hash(fileName, schema, filePath, sizeInKb, fileDescription, fileExtension);
	}
}
