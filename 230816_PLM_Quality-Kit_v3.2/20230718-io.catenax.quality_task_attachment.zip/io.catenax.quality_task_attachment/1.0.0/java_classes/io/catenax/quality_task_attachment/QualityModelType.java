
package io.catenax.quality_task_attachment;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;
import org.eclipse.esmf.aspectmodel.java.exception.EnumAttributeNotFoundException;
import org.eclipse.esmf.metamodel.datatypes.Curie;

/**
 * Generated class {@link QualityModelType}.
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum QualityModelType {
	FLEET_CLAIM_DATA("fleet.claim_data"), FLEET_DIAGNOSTIC_DATA(
			"fleet.diagnostic_data"), MANUFACTURED_PARTS_QUALITY_INFORMATION(
					"manufactured_parts_quality_information"), PARTS_ANALYSES("parts_analyses"), QUALITY_TASK(
							"quality_task"), VEHICLE_PRODUCT_DESCRIPTION("vehicle.product_description");

	private String value;

	QualityModelType(String value) {
		this.value = value;
	}

	@JsonCreator
	static QualityModelType enumDeserializationConstructor(String value) {
		return fromValue(value).orElseThrow(() -> new EnumAttributeNotFoundException(
				"Tried to parse value \"" + value + "\", but there is no enum field like that in QualityModelType"));
	}

	@JsonValue
	public String getValue() {
		return value;
	}

	public static Optional<QualityModelType> fromValue(String value) {
		return Arrays.stream(QualityModelType.values()).filter(enumValue -> compareEnumValues(enumValue, value))
				.findAny();
	}

	private static boolean compareEnumValues(QualityModelType enumValue, String value) {
		return enumValue.getValue().equals(value);
	}

}
