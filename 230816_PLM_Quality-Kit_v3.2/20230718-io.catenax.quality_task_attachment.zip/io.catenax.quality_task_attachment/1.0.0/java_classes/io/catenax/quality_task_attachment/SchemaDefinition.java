
package io.catenax.quality_task_attachment;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.eclipse.esmf.aspectmodel.java.CollectionAspect;

/**
 * Generated class for Schema. Schema for the file entities
 */

public class SchemaDefinition {
	private Optional<String> decimalSeperator;
	private Optional<String> delimiter;

	@NotNull
	private List<VariableAttribute> variables;

	@JsonCreator
	public SchemaDefinition(@JsonProperty(value = "decimalSeperator") Optional<String> decimalSeperator,
			@JsonProperty(value = "delimiter") Optional<String> delimiter,
			@JsonProperty(value = "variables") List<VariableAttribute> variables) {
		super(

		);
		this.decimalSeperator = decimalSeperator;
		this.delimiter = delimiter;
		this.variables = variables;
	}

	/**
	 * Returns Decimal Separator Enumeration
	 *
	 * @return {@link #decimalSeperator}
	 */
	public Optional<String> getDecimalSeperator() {
		return this.decimalSeperator;
	}

	/**
	 * Returns Delimiter
	 *
	 * @return {@link #delimiter}
	 */
	public Optional<String> getDelimiter() {
		return this.delimiter;
	}

	/**
	 * Returns Variables
	 *
	 * @return {@link #variables}
	 */
	public List<VariableAttribute> getVariables() {
		return this.variables;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		final SchemaDefinition that = (SchemaDefinition) o;
		return Objects.equals(decimalSeperator, that.decimalSeperator) && Objects.equals(delimiter, that.delimiter)
				&& Objects.equals(variables, that.variables);
	}

	@Override
	public int hashCode() {
		return Objects.hash(decimalSeperator, delimiter, variables);
	}
}
